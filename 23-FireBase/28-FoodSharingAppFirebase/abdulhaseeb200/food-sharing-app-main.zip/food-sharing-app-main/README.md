# food-sharing-app
A dynamic food-sharing web application with Firebase integration. Features include user authentication (signup/login), profile management with profile picture upload, and CRUD operations for food items. Users can add, edit, and delete posts, with each action confirmed via alerts. The app includes a responsive design with vibrant.
